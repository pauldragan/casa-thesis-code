/* This file is part of the OWL API.
 * The contents of this file are subject to the LGPL License, Version 3.0.
 * Copyright 2014, The University of Manchester
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.  If not, see http://www.gnu.org/licenses/.
 *
 * Alternatively, the contents of this file may be used under the terms of the Apache License, Version 2.0 in which case, the provisions of the Apache License Version 2.0 are applicable instead of those above.
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License. */
package org.semanticweb.owlapi.io;

import java.io.Serializable;

import org.semanticweb.owlapi.model.HasIRI;

/**
 * @author Matthew Horridge, The University of Manchester, Bio-Health Informatics Group
 * @since 3.2
 */
public abstract class RDFNode
    implements Serializable, Comparable<RDFNode>, HasIRI, org.apache.commons.rdf.api.RDFTerm {

    /**
     * Determines if this node is a literal node.
     *
     * @return {@code true} if this node is a literal, otherwise {@code false}.
     */
    public boolean isLiteral() {
        return false;
    }

    /**
     * Determines if this node is an axiom.
     * 
     * @return {@code true} if this node is a literal, otherwise {@code false}.
     */
    public boolean isAxiom() {
        return false;
    }

    /**
     * Determines if this node is a resource and is anonymous.
     *
     * @return {@code true} if this is a resource node (i.e. {@link #isLiteral()} returns {@code
     * false}) and the node is anonymous, or {@code false} if this is a resource node and is not
     *         anonymous.
     */
    public boolean isAnonymous() {
        return false;
    }

    /**
     * @return true if this is an anonymous individual
     */
    public boolean isIndividual() {
        return false;
    }

    /**
     * @return true if blank node id is mandatory for this resource
     */
    public boolean shouldOutputId() {
        return false;
    }

    /**
     * @return true if an id is required for this node - only if this is an individual or an axiom
     *         and id is required
     */
    public boolean idRequired() {
        return isAnonymous() && shouldOutputId();
    }
}
