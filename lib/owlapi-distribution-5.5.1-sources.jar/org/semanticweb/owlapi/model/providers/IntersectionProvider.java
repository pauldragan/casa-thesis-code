/* This file is part of the OWL API.
 * The contents of this file are subject to the LGPL License, Version 3.0.
 * Copyright 2014, The University of Manchester
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.  If not, see http://www.gnu.org/licenses/.
 *
 * Alternatively, the contents of this file may be used under the terms of the Apache License, Version 2.0 in which case, the provisions of the Apache License Version 2.0 are applicable instead of those above.
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License. */
package org.semanticweb.owlapi.model.providers;

import static org.semanticweb.owlapi.util.OWLAPIPreconditions.checkIterableNotNull;

import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Stream;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataIntersectionOf;
import org.semanticweb.owlapi.model.OWLDataRange;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.util.CollectionFactory;

/**
 * Object and datatype intersection provider.
 */
public interface IntersectionProvider {

    /**
     * @param dataRanges data ranges for intersection. Cannot be null or contain nulls.
     * @return an OWLDataIntersectionOf on the specified dataranges
     */
    default OWLDataIntersectionOf getOWLDataIntersectionOf(
        Collection<? extends OWLDataRange> dataRanges) {
        checkIterableNotNull(dataRanges, "dataRanges cannot be null", true);
        return getOWLDataIntersectionOf(dataRanges.stream());
    }

    /**
     * @param dataRanges data ranges for intersection. Cannot be null or contain nulls.
     * @return an OWLDataIntersectionOf on the specified dataranges
     */
    OWLDataIntersectionOf getOWLDataIntersectionOf(Stream<? extends OWLDataRange> dataRanges);

    /**
     * @param dataRanges data ranges for intersection. Cannot be null or contain nulls.
     * @return an OWLDataIntersectionOf on the specified dataranges
     */
    default OWLDataIntersectionOf getOWLDataIntersectionOf(OWLDataRange... dataRanges) {
        checkIterableNotNull(dataRanges, "dataRange cannot be nulls", true);
        return getOWLDataIntersectionOf(Arrays.asList(dataRanges));
    }

    /**
     * @param operands class expressions for intersection. Cannot be null or contain nulls.
     * @return an OWLObjectIntersectionOf on the specified operands
     */
    OWLObjectIntersectionOf getOWLObjectIntersectionOf(
        Stream<? extends OWLClassExpression> operands);

    /**
     * @param operands class expressions for intersection. Cannot be null or contain nulls.
     * @return an OWLObjectIntersectionOf on the specified operands
     */
    default OWLObjectIntersectionOf getOWLObjectIntersectionOf(
        Collection<? extends OWLClassExpression> operands) {
        return getOWLObjectIntersectionOf(operands.stream());
    }

    /**
     * @param operands class expressions for intersection. Cannot be null or contain nulls.
     * @return an OWLObjectIntersectionOf on the specified operands
     */
    default OWLObjectIntersectionOf getOWLObjectIntersectionOf(OWLClassExpression... operands) {
        checkIterableNotNull(operands, "operands cannot be null", true);
        return getOWLObjectIntersectionOf(CollectionFactory.createList(operands));
    }
}
