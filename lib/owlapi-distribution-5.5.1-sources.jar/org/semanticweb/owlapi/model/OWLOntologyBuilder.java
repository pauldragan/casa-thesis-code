/* This file is part of the OWL API.
 * The contents of this file are subject to the LGPL License, Version 3.0.
 * Copyright 2014, The University of Manchester
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.  If not, see http://www.gnu.org/licenses/.
 *
 * Alternatively, the contents of this file may be used under the terms of the Apache License, Version 2.0 in which case, the provisions of the Apache License Version 2.0 are applicable instead of those above.
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License. */
package org.semanticweb.owlapi.model;

import java.io.Serializable;
import java.util.concurrent.locks.ReadWriteLock;

/**
 * An ontology builder is responsible for choosing an OWLOntology implementation. This interface
 * allows for injecting different OWLOntology implementations without having to rewrite code
 * implemented in OWLOntologyFactory classes.
 *
 * @author Ignazio
 * @since 4.0.0
 */
@FunctionalInterface
public interface OWLOntologyBuilder extends Serializable {

    /**
     * @param manager manager for the ontology to be created
     * @param ontologyID id for the ontology to be created
     * @return new ontology instance
     */
    OWLOntology createOWLOntology(OWLOntologyManager manager, OWLOntologyID ontologyID);

    /**
     * Override the lock in the ontology builder; this is a workaround for #806
     * 
     * @param lock overriding lock instance to use
     */
    default void setLock(@SuppressWarnings("unused") ReadWriteLock lock) {
        // do nothing for the default implementation
    }
}
